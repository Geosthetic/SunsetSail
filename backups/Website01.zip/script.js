/**
 * Sunset & Sail Travel — script.js
 * Responsibilities:
 *  1. Load bundle data (API if available, fallback to static catalog)
 *  2. Handle the quote request form
 *  3. Expose a tiny client-side adapter so agents/APIs have a predictable surface
 */

/* ------------------------------------------------------------------
 * CONFIG — point these at your real backend when ready
 * ------------------------------------------------------------------ */
const API_CONFIG = {
  baseUrl: 'https://api.sunsetsailtravel.example/v1',
  endpoints: {
    bundles: '/bundles',       // GET → list of active cruise bundles
    quotes:  '/quote-requests' // POST → submit quote request
  },
  timeoutMs: 6000
};

/* ------------------------------------------------------------------
 * STATIC CATALOG — the "knowledge cluster" fallback.
 * Keep in sync with JSON-LD schema in index.html.
 * ------------------------------------------------------------------ */
const FALLBACK_BUNDLES = [
  {
    id: 'caribbean-bundle',
    name: '7-Night Western Caribbean Cruise Bundle',
    nights: 7,
    region: 'Caribbean',
    summary: 'Round-trip flights, 1-night pre-cruise hotel with transfers, 7-night cruise to Cozumel, Grand Cayman & Jamaica, rental car, two shore excursion tickets.',
    pricePerPerson: 1899,
    currency: 'USD',
    inStock: true,
    includes: ['Round-trip air', 'Pre-cruise hotel', 'Port transfers', 'Rental car', '2 shore excursion tickets']
  },
  {
    id: 'alaska-bundle',
    name: '10-Night Alaska Glacier Cruise Bundle',
    nights: 10,
    region: 'Alaska',
    summary: 'Flights to Seattle, pre-cruise hotel, glacier itinerary, Seattle city tour, post-cruise attraction day pass.',
    pricePerPerson: 2749,
    currency: 'USD',
    inStock: true,
    includes: ['Round-trip air', 'Pre-cruise hotel', 'City tour', 'Attraction day pass']
  },
  {
    id: 'mediterranean-bundle',
    name: '12-Night Mediterranean Grand Tour Bundle',
    nights: 12,
    region: 'Mediterranean',
    summary: 'Flights to Barcelona, 2-night pre-cruise hotel, 12-night cruise, rail pass, skip-the-line tickets.',
    pricePerPerson: 3999,
    currency: 'USD',
    inStock: false, // Limited availability
    includes: ['Round-trip air', '2 hotel nights', 'Rail pass', 'Attraction tickets']
  }
];

/* ------------------------------------------------------------------
 * DATA LOADING
 * ------------------------------------------------------------------ */
async function fetchWithTimeout(url, options = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), API_CONFIG.timeoutMs);
  try {
    return await fetch(url, { ...options, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

async function loadBundles() {
  try {
    const res = await fetchWithTimeout(`${API_CONFIG.baseUrl}${API_CONFIG.endpoints.bundles}`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } catch (err) {
    console.info('Bundles API unavailable, using static catalog.', err.message);
    return FALLBACK_BUNDLES;
  }
}

function renderBundles(bundles) {
  const grid = document.getElementById('bundleGrid');
  if (!grid || !Array.isArray(bundles)) return;

  grid.innerHTML = bundles.map(b => `
    <article class="bundle-card" data-bundle-id="${b.id}">
      <h3>${escapeHtml(b.name)}</h3>
      <p>${escapeHtml(b.description || b.summary || '')}</p>
      ${b.inStock === false ? '<p class="badge badge-limited">Limited availability</p>' : ''}
      <ul class="bundle-includes">
        ${(b.includes || []).map(i => `<li>${escapeHtml(i)}</li>`).join('')}
      </ul>
      <p class="price">From <span>$${Number(b.pricePerPerson).toLocaleString()}</span> per person</p>
      <a class="btn btn-secondary" href="#quote" data-prefill="${b.id}">Ask about this bundle</a>
    </article>
  `).join('');

  // Prefill the quote form when someone clicks a specific bundle
  grid.querySelectorAll('[data-prefill]').forEach(link => {
    link.addEventListener('click', () => {
      const select = document.getElementById('qInterest');
      if (select) select.value = link.dataset.prefill;
    });
  });
}

/* ------------------------------------------------------------------
 * QUOTE FORM
 * ------------------------------------------------------------------ */
async function submitQuote(payload) {
  try {
    const res = await fetchWithTimeout(
      `${API_CONFIG.baseUrl}${API_CONFIG.endpoints.quotes}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }
    );
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return { ok: true };
  } catch (err) {
    console.warn('Quote API unavailable; falling back to mailto handoff.', err);
    return { ok: false, payload };
  }
}

function wireQuoteForm() {
  const form = document.getElementById('quoteForm');
  const status = document.getElementById('formStatus');
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    if (!form.reportValidity()) return;

    const formData = Object.fromEntries(new FormData(form));
    formData.partySize = Number(formData.partySize) || 2;
    formData.submittedAt = new Date().toISOString();

    status.textContent = 'Sending your request…';
    const result = await submitQuote(formData);

    if (result.ok) {
      status.textContent = '✅ Thanks! Your quote request was received — expect a reply within 1 business day.';
      form.reset();
    } else {
      // Human-in-the-loop fallback: open the visitor's email client pre-filled
      const subject = encodeURIComponent(`Quote request: ${formData.bundle || 'cruise bundle'} (${formData.partySize} travelers)`);
      const body = encodeURIComponent(
        `Name: ${formData.name}\nEmail: ${formData.email}\n` +
        `Departure: ${formData.departureCity}\nBundle: ${formData.bundle}\n` +
        `Travelers: ${formData.partySize}\nNotes: ${formData.notes}`
      );
      window.location.href = `mailto:quotes@sunsetsailtravel.example?subject=${subject}&body=${body}`;
      status.textContent = 'Opening your email app to finish sending the request…';
    }
  });
}

/* ------------------------------------------------------------------
 * UTILITIES
 * ------------------------------------------------------------------ */
function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = String(str ?? '');
  return div.innerHTML;
}

/* ------------------------------------------------------------------
 * INIT
 * ------------------------------------------------------------------ */
document.addEventListener('DOMContentLoaded', async () => {
  renderBundles(await loadBundles());
  wireQuoteForm();
});
